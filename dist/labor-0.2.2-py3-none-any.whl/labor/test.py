
from labor.controllers.login import LoginController


def main():

    LoginController().sign_in()


if __name__ == '__main__':

    main()
